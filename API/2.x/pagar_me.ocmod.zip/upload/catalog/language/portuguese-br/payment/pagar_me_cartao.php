<?php
$_['text_wait']         = 'Por favor, aguarde!';
$_['button_confirm'] = 'Confirmar compra';

/*Erro*/
$_['heading_title']   = 'Pedido não aprovado!';

// Text
$_['text_customer']   = '<p>Seu pedido não foi aprovado!</p><p><strong>Você pode entrar em contato com a sua operadora de cartão e verificar se o seu cartão está desbloqueado para compras online.</strong></p><p>Você pode tambem, ver o histórico dos seus pedidos acessando sua conta e clicando em <a href="%s">Histórico de Pedidos</a>.</p><p>Por favor, entre em contato conosco para dúvidas clicando <a href="%s">aqui</a>.</p>';
$_['text_guest']      = '<p>Seu pedido não foi aprovado!</p><p><strong>Você pode entrar em contato com a sua operadora de cartão e verificar se o seu cartão está desbloqueado para compras online.</strong></p><p>Por favor, entre em contato conosco para dúvidas clicando <a href="%s">aqui</a>.</p>';
$_['text_basket']     = 'Meu Carrinho';
$_['text_checkout']   = 'Finalizar Compra';
$_['text_no_success'] = 'Pedido não Aprovado';
?>